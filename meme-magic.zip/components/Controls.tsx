
import React, { useState } from 'react';
import { LoadingState } from '../types';
import { MagicWandIcon, EditIcon, ResetIcon, LoadingSpinner } from './icons';

interface ControlsProps {
  onMagicCaption: () => void;
  onEditImage: (prompt: string) => void;
  onReset: () => void;
  captions: string[];
  onCaptionSelect: (caption: string) => void;
  loading: LoadingState;
}

export const Controls: React.FC<ControlsProps> = ({
  onMagicCaption,
  onEditImage,
  onReset,
  captions,
  onCaptionSelect,
  loading,
}) => {
  const [editPrompt, setEditPrompt] = useState('');

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onEditImage(editPrompt);
  };
  
  return (
    <div className="bg-gray-800 p-6 rounded-2xl border border-gray-700 flex flex-col gap-6">
      <div>
        <h2 className="text-xl font-semibold mb-4 text-gray-200">2. Generate & Edit</h2>
        <div className="flex flex-col gap-4">
          <button
            onClick={onMagicCaption}
            disabled={loading !== 'idle'}
            className="w-full flex items-center justify-center gap-2 bg-purple-600 hover:bg-purple-500 disabled:bg-purple-800 disabled:cursor-not-allowed text-white font-semibold py-3 px-4 rounded-lg transition-colors duration-300"
          >
            {loading === 'captions' ? <LoadingSpinner /> : <MagicWandIcon />}
            Magic Caption
          </button>
          <form onSubmit={handleEditSubmit} className="flex flex-col sm:flex-row gap-2">
            <input
              type="text"
              value={editPrompt}
              onChange={(e) => setEditPrompt(e.target.value)}
              placeholder="e.g., add a retro filter"
              className="flex-grow bg-gray-700 text-white border border-gray-600 rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition"
              disabled={loading !== 'idle'}
            />
            <button
              type="submit"
              disabled={loading !== 'idle' || !editPrompt}
              className="flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-800 disabled:cursor-not-allowed text-white font-semibold py-2 px-4 rounded-lg transition-colors duration-300"
            >
              {loading === 'editing' ? <LoadingSpinner /> : <EditIcon />}
              Apply Edit
            </button>
          </form>
        </div>
      </div>
      
      {captions.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold mb-3 text-gray-300">Suggestions:</h3>
          <div className="flex flex-col gap-2">
            {captions.map((caption, index) => (
              <button
                key={index}
                onClick={() => onCaptionSelect(caption)}
                className="w-full text-left bg-gray-700/50 hover:bg-gray-700 p-3 rounded-lg text-sm text-gray-200 transition-colors duration-200"
              >
                "{caption}"
              </button>
            ))}
            <button
                onClick={() => onCaptionSelect('')}
                className="w-full text-center text-gray-400 hover:text-white p-2 rounded-lg text-sm transition-colors"
            >
                Clear Caption
            </button>
          </div>
        </div>
      )}
       <button
            onClick={onReset}
            disabled={loading !== 'idle'}
            className="w-full flex items-center justify-center gap-2 mt-4 bg-gray-700 hover:bg-gray-600 disabled:bg-gray-800 disabled:cursor-not-allowed text-gray-300 font-semibold py-2 px-4 rounded-lg transition-colors duration-300"
        >
          <ResetIcon />
          Start Over
        </button>
    </div>
  );
};


import React from 'react';

export const UploadIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
  </svg>
);

export const MagicWandIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.25278V4.75278C12 4.47664 12.2239 4.25278 12.5 4.25278C12.7761 4.25278 13 4.47664 13 4.75278V6.25278C13 6.52893 12.7761 6.75278 12.5 6.75278C12.2239 6.75278 12 6.52893 12 6.25278Z M8.00001 7.25277L9.06067 8.31343C9.25594 8.50869 9.25594 8.82527 9.06067 9.02054C8.86541 9.2158 8.54883 9.2158 8.35356 9.02054L7.2929 7.95988C7.09764 7.76462 7.09764 7.44804 7.2929 7.25277C7.48816 7.05751 7.80474 7.05751 8.00001 7.25277Z M6.5 12.2528H5C4.72386 12.2528 4.5 12.4766 4.5 12.7528C4.5 13.0289 4.72386 13.2528 5 13.2528H6.5C6.77614 13.2528 7 13.0289 7 12.7528C7 12.4766 6.77614 12.2528 6.5 12.2528Z M9.06066 16.4852L8 17.5459C7.80474 17.7411 7.48816 17.7411 7.29289 17.5459C7.09763 17.3506 7.09763 17.034 7.29289 16.8388L8.35355 15.7781C8.54882 15.5828 8.8654 15.5828 9.06066 15.7781C9.25592 15.9733 9.25592 16.2899 9.06066 16.4852Z M12.5 19.2528C12.2239 19.2528 12 19.0289 12 18.7528V17.2528C12 16.9766 12.2239 16.7528 12.5 16.7528C12.7761 16.7528 13 16.9766 13 17.2528V18.7528C13 19.0289 12.7761 19.2528 12.5 19.2528Z M10 13.2528L17.5 5.75278L19 7.25278L11.5 14.7528L10 15.2528L10.5 13.7528L10 13.2528Z" />
    </svg>
);

export const EditIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.5L15.232 5.232z" />
    </svg>
);

export const ResetIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h5M20 20v-5h-5M4 4l16 16" />
    </svg>
);

export const LoadingSpinner = () => (
    <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
    </svg>
);

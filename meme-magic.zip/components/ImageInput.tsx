
import React, { useRef } from 'react';
import { UploadIcon } from './icons';
import { MemeTemplate } from '../types';

interface ImageInputProps {
  onImageSelected: (base64: string) => void;
  onTemplateSelected: (template: MemeTemplate) => void;
  templates: MemeTemplate[];
  disabled: boolean;
}

export const ImageInput: React.FC<ImageInputProps> = ({ onImageSelected, onTemplateSelected, templates, disabled }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        onImageSelected(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className={`bg-gray-800 p-6 rounded-2xl border border-gray-700 transition-opacity duration-300 ${disabled ? 'opacity-50' : ''}`}>
      <h2 className="text-xl font-semibold mb-4 text-gray-200">1. Choose an Image</h2>
      <div className="flex flex-col gap-4">
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          accept="image/*"
          className="hidden"
          disabled={disabled}
        />
        <button
          onClick={handleUploadClick}
          disabled={disabled}
          className="w-full flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-800 disabled:cursor-not-allowed text-white font-semibold py-3 px-4 rounded-lg transition-colors duration-300"
        >
          <UploadIcon />
          Upload Your Own
        </button>
        
        <div className="relative">
          <div className="absolute inset-0 flex items-center" aria-hidden="true">
            <div className="w-full border-t border-gray-600" />
          </div>
          <div className="relative flex justify-center">
            <span className="bg-gray-800 px-2 text-sm text-gray-400">OR</span>
          </div>
        </div>

        <p className="text-gray-400 text-sm">Select a trending template:</p>
        <div className="grid grid-cols-3 gap-2">
          {templates.map((template) => (
            <button key={template.name} onClick={() => onTemplateSelected(template)} disabled={disabled} className="aspect-square rounded-md overflow-hidden transition-transform transform hover:scale-105 disabled:transform-none disabled:cursor-not-allowed">
              <img src={template.url} alt={template.name} className="w-full h-full object-cover" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

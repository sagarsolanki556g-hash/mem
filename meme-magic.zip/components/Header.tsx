
import React from 'react';

export const Header: React.FC = () => {
  return (
    <header className="text-center">
      <h1 className="text-4xl md:text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-indigo-500">
        Meme Magic
      </h1>
      <p className="mt-2 text-lg text-gray-400">
        Your AI-powered meme generator. Let Gemini do the thinking.
      </p>
    </header>
  );
};

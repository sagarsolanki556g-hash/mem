
import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { ImageInput } from './components/ImageInput';
import { MemeCanvas } from './components/MemeCanvas';
import { Controls } from './components/Controls';
import { generateCaptions, editImageWithPrompt } from './services/geminiService';
import { LoadingState } from './types';
import { MemeTemplate } from './types';
import { TEMPLATES } from './constants';

const App: React.FC = () => {
  const [originalImage, setOriginalImage] = useState<string | null>(null);
  const [editedImage, setEditedImage] = useState<string | null>(null);
  const [captions, setCaptions] = useState<string[]>([]);
  const [selectedCaption, setSelectedCaption] = useState<string>('');
  const [loading, setLoading] = useState<LoadingState>('idle');
  const [error, setError] = useState<string | null>(null);

  const handleImageSelected = useCallback((imageBase64: string) => {
    setOriginalImage(imageBase64);
    setEditedImage(imageBase64);
    setCaptions([]);
    setSelectedCaption('');
    setError(null);
  }, []);
  
  const handleReset = () => {
    setOriginalImage(null);
    setEditedImage(null);
    setCaptions([]);
    setSelectedCaption('');
    setError(null);
  }

  const handleMagicCaption = async () => {
    if (!originalImage) return;
    setLoading('captions');
    setError(null);
    setCaptions([]);
    setSelectedCaption('');
    try {
      const result = await generateCaptions(originalImage);
      setCaptions(result);
    } catch (err) {
      setError('Failed to generate captions. Please try again.');
      console.error(err);
    } finally {
      setLoading('idle');
    }
  };

  const handleEditImage = async (prompt: string) => {
    if (!originalImage || !prompt) return;
    setLoading('editing');
    setError(null);
    try {
      const result = await editImageWithPrompt(originalImage, prompt);
      setEditedImage(result);
      // Clear captions as they might not be relevant anymore
      setCaptions([]);
      setSelectedCaption('');
    } catch (err) {
      setError('Failed to edit the image. Please try again.');
      console.error(err);
    } finally {
      setLoading('idle');
    }
  };
  
    const selectTemplate = async (template: MemeTemplate) => {
        try {
            const response = await fetch(template.url);
            const blob = await response.blob();
            const reader = new FileReader();
            reader.onloadend = () => {
                handleImageSelected(reader.result as string);
            };
            reader.readAsDataURL(blob);
        } catch (error) {
            console.error("Error fetching template image:", error);
            setError("Could not load template image.");
        }
    };


  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 flex flex-col p-4 md:p-8">
      <Header />
      <main className="flex-grow flex flex-col lg:flex-row gap-8 mt-6">
        <div className="lg:w-1/3 flex flex-col gap-6">
          <ImageInput onImageSelected={handleImageSelected} onTemplateSelected={selectTemplate} templates={TEMPLATES} disabled={!!originalImage} />
          {originalImage && (
            <Controls
              onMagicCaption={handleMagicCaption}
              onEditImage={handleEditImage}
              onReset={handleReset}
              captions={captions}
              onCaptionSelect={setSelectedCaption}
              loading={loading}
            />
          )}
           {error && (
            <div className="bg-red-900 border border-red-700 text-red-200 px-4 py-3 rounded-lg" role="alert">
              <p className="font-bold">Error</p>
              <p className="text-sm">{error}</p>
            </div>
          )}
        </div>
        <div className="lg:w-2/3 flex-grow flex items-center justify-center bg-gray-800/50 rounded-2xl border border-gray-700 p-4 min-h-[300px] md:min-h-[500px]">
          <MemeCanvas image={editedImage} caption={selectedCaption} loading={loading !== 'idle'} />
        </div>
      </main>
    </div>
  );
};

export default App;

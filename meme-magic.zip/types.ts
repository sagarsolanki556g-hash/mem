
export type LoadingState = 'idle' | 'captions' | 'editing';

export interface MemeTemplate {
  name: string;
  url: string;
}

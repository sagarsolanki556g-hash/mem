
import { MemeTemplate } from './types';

export const TEMPLATES: MemeTemplate[] = [
  {
    name: 'Drake Hotline Bling',
    url: 'https://i.imgflip.com/30b1gx.jpg',
  },
  {
    name: 'Distracted Boyfriend',
    url: 'https://i.imgflip.com/1ur9b0.jpg',
  },
  {
    name: 'Woman Yelling at a Cat',
    url: 'https://i.imgflip.com/345v97.jpg',
  },
  {
    name: 'Two Buttons',
    url: 'https://i.imgflip.com/1g8my4.jpg',
  },
  {
    name: 'Change My Mind',
    url: 'https://i.imgflip.com/24y43o.jpg',
  },
  {
    name: 'Is This A Pigeon',
    url: 'https://i.imgflip.com/2x1hf.jpg',
  },
];
